
function profiles(){                                        //  To open index.html
    window.open("index.html");
}

let userBox = document.getElementById("userBox");

function openinfo(){                                    //  To open the user profile card
    userBox.classList.remove("hide-details");
}

function closeinfo(){                                   //  To close the user profile card
    userBox.classList.add("hide-details");
}

function Submit() {                                     //  Submit function to print values in user profile card
    
        //  Name Value
        document.getElementById("myForm").addEventListener("submit", function(event) {
            event.preventDefault();
            var inputValue1 = document.getElementById("name").value;
            var outputElement1 = document.getElementById("Oname");
        
            outputElement1.innerHTML = inputValue1;
            });
        
                //  Profession Value
            document.getElementById("myForm").addEventListener("submit", function(event) {
            event.preventDefault();
            var inputValue2 = document.getElementById("Profession").value;
            var outputElement2 = document.getElementById("OProfession");
        
            outputElement2.innerHTML = inputValue2;
            });
        
                //  Company Value
            document.getElementById("myForm").addEventListener("submit", function(event) {
            event.preventDefault();
            var inputValue3 = document.getElementById("CName").value;
            var outputElement3 = document.getElementById("OCName");
            
            outputElement3.innerHTML = inputValue3;
            });
        
                //  Company Address Value
            document.getElementById("myForm").addEventListener("submit", function(event) {
            event.preventDefault();
            var inputValue4 = document.getElementById("CAddress").value;
            var outputElement4 = document.getElementById("OCAddress");
            
            outputElement4.innerHTML = inputValue4;
            });
        
                //  Bio Value
            document.getElementById("myForm").addEventListener("submit", function(event) {
            event.preventDefault();
            var inputValue5 = document.getElementById("Bio").value;
            var outputElement5 = document.getElementById("OBio");
            
            outputElement5.innerHTML = inputValue5;
            });

}

